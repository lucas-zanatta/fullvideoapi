module.exports = {
	...require('n8n-workflow/.prettierrc.js'),
};

